package com.example.hospital.util;

public class UIUtil {
    
}
